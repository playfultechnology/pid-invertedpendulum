#ifndef __SHOW_H
#define __SHOW_H
#include "sys.h"
  /**************************************************************************
���ߣ�ƽ��С��֮��
�ҵ��Ա�С�꣺http://shop114407458.taobao.com/
**************************************************************************/
void oled_show(void);
void DataScope(void);
void show_Tips(void);

void step_0(void);
void step_1(void);
void step_2(void);
void step_3(void);
void success_display(void);
void check_display(void);
void fail_display(void);
#endif
