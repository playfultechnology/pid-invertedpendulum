#ifndef __CHECK_H
#define __CHECK_H
#include "sys.h"

void Tips(void);
extern u8 tips_flag;

#endif
